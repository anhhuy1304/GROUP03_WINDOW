dung ham EnableAutoStartup de chay chuong trinh khi khoi dong

khi khong muon tu khoi dong nua thi chay ham DisableAutoStartup